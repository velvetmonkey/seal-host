#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
#
# Anti-drift gate for the single-source policy codec.
#
#   1. BYTE-COMPARE `seal-host-rs schema` against the schema artifact checked
#      into the pinned authority (.lake/packages/mcp-seal/docs/
#      policy-bundle.schema.json). A stale artifact fails CI.
#   2. Verify the shipped trusted example's Ed25519 signature over its exact
#      payload bytes against the separately documented example trust root.
#   3. Run `seal-host-rs validate` — the Lean parser chain AND the
#      emitted-schema validator in the SAME invocation — over every real
#      policy payload in the repo (config examples, profile payloads,
#      envelope example) and assert full agreement (agree_accept).
#   4. Run the negative parity corpus (unknown keys, missing fields, wrong
#      types, enum/discriminator, aliases, defaults, parser-only
#      refinements) and assert the EXPECTED agreement class per case —
#      including the host-layer duplicate-Budget-cap rejection the signer
#      does not check (lean stage=host, schema accepts: the documented gap).
#
# Any schema_rejects_parsed_policy anywhere is drift and fails (exit 1 from
# the binary); any unexpected agreement class fails this script.
set -euo pipefail

SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
if [[ "$SCRIPT_DIR" == "${BASH_SOURCE[0]}" ]]; then
  SCRIPT_DIR=.
fi
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT"
BIN="${SEAL_HOST_BIN:-rust/target/debug/seal-host-rs}"
ARTIFACT=".lake/packages/mcp-seal/docs/policy-bundle.schema.json"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "==> [1/4] schema byte-compare vs pinned authority artifact"
"$BIN" schema > "$TMP/schema.json"
if ! diff -u "$ARTIFACT" "$TMP/schema.json"; then
  echo "FAIL: emitted schema differs from pinned authority artifact" >&2
  exit 1
fi
echo "    schema byte-identical to $ARTIFACT"

echo "==> [2/4] trusted example signature vs documented trust root"
python3 - config/trusted.example.json config/trusted.example.pub <<'PY'
import json
import sys

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

envelope_path, public_key_path = sys.argv[1:]
with open(envelope_path, encoding="utf-8") as f:
    envelope = json.load(f)
with open(public_key_path, encoding="ascii") as f:
    public_key = bytes.fromhex(f.read().strip())

try:
    signature = bytes.fromhex(envelope["signature"])
    payload = envelope["payload"].encode("utf-8")
    Ed25519PublicKey.from_public_bytes(public_key).verify(signature, payload)
except (InvalidSignature, KeyError, TypeError, ValueError) as error:
    detail = type(error).__name__ if not str(error) else str(error)
    raise SystemExit(
        f"FAIL: {envelope_path} signature invalid under {public_key_path}: {detail}"
    )

print(f"    ok: {envelope_path} signature valid under {public_key_path}")
PY

expect_class() { # file expected-class [expected-lean-stage] [expected-lean-error]
  local file="$1" expected="$2" stage="${3:-}" expected_error="${4:-}"
  local line
  line="$("$BIN" validate "$file")" || {
    # nonzero exit is legal only for expected hard failures; we never expect one
    echo "FAIL: validate exited nonzero on $file" >&2; exit 1; }
  local got
  got="$(printf '%s' "$line" | python3 -c 'import json,sys; print(json.loads(sys.stdin.readline())["agreement"])')"
  if [ "$got" != "$expected" ]; then
    echo "FAIL: $file expected $expected got $got" >&2
    printf '%s\n' "$line" >&2
    exit 1
  fi
  if [ -n "$stage" ]; then
    local gotstage
    gotstage="$(printf '%s' "$line" | python3 -c 'import json,sys; print(json.loads(sys.stdin.readline())["lean_stage"])')"
    if [ "$gotstage" != "$stage" ]; then
      echo "FAIL: $file expected lean stage $stage got $gotstage" >&2
      printf '%s\n' "$line" >&2
      exit 1
    fi
  fi
  if [ -n "$expected_error" ]; then
    local goterror
    goterror="$(printf '%s' "$line" | python3 -c 'import json,sys; print(json.loads(sys.stdin.readline())["lean"].get("error", ""))')"
    if [ "$goterror" != "$expected_error" ]; then
      echo "FAIL: $file expected Lean error '$expected_error' got '$goterror'" >&2
      printf '%s\n' "$line" >&2
      exit 1
    fi
  fi
  echo "    ok: $(basename "$file") -> $expected${stage:+ (stage=$stage)}"
}

echo "==> [3/4] real payloads: parser and schema must both accept"
for f in config/payload.example.json config/trusted.example.json \
         profiles/policies-v1/*.payload.json profiles/policies-v2/*.payload.json; do
  expect_class "$f" agree_accept
done

echo "==> [4/4] negative parity corpus"
SAFETY='"safety":{"approval":{"control_file":"/tmp/a","ttl_seconds":60},"tools":[{"name":"t","mode":"guard","target":[{"full_arguments":true}]}]}'

mk() { printf '%s' "$2" > "$TMP/$1"; }

# agree_reject: strictness both sides see
mk unknown-top.json          '{"epoch":1,'"$SAFETY"',"temporral":{}}'
mk unknown-section-key.json  '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[],"cap":1}}'
mk unknown-entry-key.json    '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[{"name":"n","cap":1,"tools":[],"costs":1}]}}'
mk missing-epoch.json        '{'"$SAFETY"'}'
mk epoch-zero.json           '{"epoch":0,'"$SAFETY"'}'
mk missing-safety.json       '{"epoch":1}'
mk missing-control-file.json '{"epoch":1,"safety":{"approval":{"ttl_seconds":9},"tools":[]}}'
mk wrong-type-cap.json       '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[{"name":"n","cap":"1","tools":[]}]}}'
mk bad-mode-enum.json        '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"block"}]}}'
mk bad-match-discriminator.json '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","match":{"type":"regex","arg":"a"}}]}}'
mk bad-temporal-type.json    '{"epoch":1,'"$SAFETY"',"temporal":{"policies":[{"name":"n","type":"eventually","trigger":[],"forbidden":[]}]}}'
for f in unknown-top unknown-section-key unknown-entry-key missing-epoch epoch-zero \
         missing-safety missing-control-file wrong-type-cap bad-mode-enum \
         bad-match-discriminator bad-temporal-type; do
  expect_class "$TMP/$f.json" agree_reject
done

# island not/const:true + needles-typing regression pins (council bae27e33, 2026-07-19).
# These agree_reject TODAY. They exist to FREEZE the two fragile hand-schema
# constructs so a future silent weakening breaks THIS gate instead of shipping:
#   - full_arguments schema uses `const:true` (NOT `type:boolean`). Weaken it to
#     type:boolean and {full_arguments:false} becomes schema-accept / parser-reject
#     = parser_refinement, so the expected class flips agree_reject -> and this pin
#     FAILS. That is the point: the const:true logic can no longer drift silently.
#   - contains_any_ci needles items:{type:string}. Drop the item type and a
#     non-string needle becomes schema-accept / parser-reject (parser: mapM getStr?),
#     again flipping the expected class and failing the pin.
mk full-args-false.json      '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","target":[{"full_arguments":false}]}]}}'
mk full-args-nonbool.json    '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","target":[{"full_arguments":"true"}]}]}}'
mk needle-nonstring.json     '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","match":{"type":"contains_any_ci","arg":"s","needles":[1]}}]}}'
for f in full-args-false full-args-nonbool needle-nonstring; do
  expect_class "$TMP/$f.json" agree_reject
done

# NOTE — serde recursion asymmetry (council bae27e33 / Grok, 2026-07-19).
# There is deliberately NO deep-nested all/any case here. At match nesting
# depth ~65+, serde_json's default value-recursion limit (~128 nests, ~2 per
# match level) rejects the payload in the schema/validate lane BEFORE the
# jsonschema $ref body is ever consulted, while the Lean parser accepts it.
# That is a serde_json infrastructure limit, NOT hand-schema island drift.
# Adding a deep-nest case now would hard-fail CI for the wrong reason and
# misread as island drift. Follow-up before any deep-nest case is added:
# raise/disable the recursion limit on the validate-path parse (rust/src, the
# serde_json::from_str feeding the schema instance), THEN pin a deep nest as
# agree_accept. Fail-closed, not a signing bypass: schema rejects, never blesses.

# agree_accept: aliases, defaults, permissive interior, every match variant
mk alias-guarded.json        '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"a","mode":"guard","target":[{"full_arguments":true}]},{"name":"b","mode":"guarded","target":[{"full_arguments":true}]}]}}'
mk defaults.json             '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"allow"}]}}'
mk permissive-interior.json  '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","_comment":"x","match":{"type":"always","note":1},"target":[{"full_arguments":true}]}]}}'
mk match-variants.json       '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guard","match":{"type":"all","matches":[{"type":"always"},{"type":"equals","arg":"a.b","value":"v"},{"type":"starts_with","arg":"p","value":"q"},{"type":"contains_any_ci","arg":"s","needles":["x"]},{"type":"any","matches":[{"type":"always"}]}]},"target":[{"full_arguments":true}]}]}}'
for f in alias-guarded defaults permissive-interior match-variants; do
  expect_class "$TMP/$f.json" agree_accept
done

# parser_refinement: Lean-only refinements the schema cannot express
mk guard-non-full-target.json '{"epoch":1,"safety":{"approval":{"control_file":"c"},"tools":[{"name":"t","mode":"guarded","target":[{"literal":"x"}]}]}}'
mk server-conflict.json      '{"epoch":1,"server":"outer","safety":{"server":"inner","approval":{"control_file":"c"},"tools":[]}}'
mk calibration-delta.json    '{"epoch":1,'"$SAFETY"',"calibration":{"delta_num":3,"delta_den":2,"min_samples":1,"records_file":"r","gated_tools":[]}}'
mk pathological-number.json  '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[{"name":"n","cap":1e9999999,"tools":[]}]}}'
expect_class "$TMP/guard-non-full-target.json" parser_refinement parse 'guard mode requires target [{"full_arguments": true}]'
expect_class "$TMP/server-conflict.json" parser_refinement parse
expect_class "$TMP/calibration-delta.json" parser_refinement parse
# both lanes refuse the pathological exponent (Lean: fail-closed number
# guard; serde_json: "number out of range"), so this is agree_reject —
# asserted with the stage pinned so the Lean side is provably the guard.
expect_class "$TMP/pathological-number.json" agree_reject number-guard

# the signer/host gap: duplicate Budget cap conflict — parser AND schema
# accept, the host mapping rejects; `seal validate` must catch it (stage=host)
mk dup-budget-cap.json       '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[{"name":"n","cap":1,"tools":[]},{"name":"n","cap":2,"tools":[]}]}}'
expect_class "$TMP/dup-budget-cap.json" parser_refinement host

# equal-cap duplicates stay legal end to end
mk dup-budget-equal.json     '{"epoch":1,'"$SAFETY"',"budget":{"budgets":[{"name":"n","cap":1,"tools":[]},{"name":"n","cap":1,"tools":[]}]}}'
expect_class "$TMP/dup-budget-equal.json" agree_accept

echo "POLICY SCHEMA GATE PASS"
